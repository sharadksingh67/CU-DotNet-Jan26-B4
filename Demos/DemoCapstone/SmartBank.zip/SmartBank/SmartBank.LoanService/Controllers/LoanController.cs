﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartBank.LoanService.DTOs;
using SmartBank.LoanService.Services;
using System.Security.Claims;

namespace SmartBank.LoanService.Controllers
{
    [ApiController]
    [Route("api/loans")]
    [Authorize]
    public class LoanController : ControllerBase
    {
        private readonly ILoanService _service;

        public LoanController(ILoanService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetLoans()
        {
            // Extract UserId from JWT
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var result = await _service.GetLoans(userId);

            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Apply(CreateLoanDto dto)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var loan = await _service.ApplyLoan(dto, userId);
            return Ok(loan);
        }

        [HttpPost("{id}/approve")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Approve(int id)
        {
            var token = Request.Headers["Authorization"]
                            .ToString()
                            .Replace("Bearer ", "");

            await _service.ApproveLoan(id, token);

            return Ok("Loan Approved");
        }
    }
}
