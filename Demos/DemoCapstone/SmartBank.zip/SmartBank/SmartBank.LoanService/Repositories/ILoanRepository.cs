﻿using SmartBank.LoanService.Models;

namespace SmartBank.LoanService.Repositories
{
    public interface ILoanRepository
    {
        Task AddAsync(Loan loan);
        Task<Loan> GetByIdAsync(int id);
        Task UpdateAsync(Loan loan);
        Task<List<Loan>> GetByUserIdAsync(string userId);
    }
}
