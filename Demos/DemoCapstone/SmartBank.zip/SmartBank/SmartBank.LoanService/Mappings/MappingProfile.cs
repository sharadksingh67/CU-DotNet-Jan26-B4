﻿using AutoMapper;
using SmartBank.LoanService.DTOs;
using SmartBank.LoanService.Models;

namespace SmartBank.LoanService.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Loan, LoanDto>();
            CreateMap<CreateLoanDto, Loan>();
            CreateMap<Loan, LoanDto>();
        }
    }
}
