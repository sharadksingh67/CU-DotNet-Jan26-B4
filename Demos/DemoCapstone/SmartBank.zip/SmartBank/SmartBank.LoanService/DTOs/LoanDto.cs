﻿namespace SmartBank.LoanService.DTOs
{
    public class LoanDto
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public decimal InterestRate { get; set; }
        public int TenureMonths { get; set; }
        public decimal EMI { get; set; }
        public string Status { get; set; }
    }
    //public class LoanDto
    //{
    //    public int Id { get; set; }
    //    public decimal Amount { get; set; }
    //    public decimal EMI { get; set; }
    //    public string Status { get; set; }
    //}

}
