﻿namespace SmartBank.LoanService.DTOs
{
    public class CreateLoanDto
    {
        public int AccountId { get; set; }
        public decimal Amount { get; set; }
        public decimal InterestRate { get; set; }
        public int TenureMonths { get; set; }
    }
}
