﻿namespace SmartBank.LoanService.Models
{
    public class Loan
    {
        public int Id { get; set; }

        public string UserId { get; set; }

        public int AccountId { get; set; }

        public decimal Amount { get; set; }

        public decimal InterestRate { get; set; }

        public int TenureMonths { get; set; }

        public decimal EMI { get; set; }

        public string Status { get; set; } // Pending, Approved, Rejected

        public DateTime CreatedAt { get; set; }
    }
}
