﻿namespace SmartBank.LoanService.Services
{
    using System.Net.Http.Headers;
    using System.Text;
    using System.Text.Json;

    public class AccountApiClient : IAccountApiClient
    {
        private readonly IHttpClientFactory _factory;

        public AccountApiClient(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        public async Task Deposit(int accountId, decimal amount, string token)
        {
            var client = _factory.CreateClient("AccountService");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var content = new StringContent(
                JsonSerializer.Serialize(new
                {
                    accountId = accountId,
                    amount = amount
                }),
                Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync("accounts/deposit", content);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"Account service failed: {error}");
            }
        }
    }
}
