﻿using AutoMapper;
using SmartBank.LoanService.DTOs;
using SmartBank.LoanService.Models;
using SmartBank.LoanService.Repositories;

namespace SmartBank.LoanService.Services
{
    public class LoanService : ILoanService
    {
        private readonly ILoanRepository _repo;
        private readonly IAccountApiClient _accountClient;
        private readonly IMapper _mapper;

        public LoanService(ILoanRepository repo,
                           IAccountApiClient accountClient,
                           IMapper mapper)
        {
            _repo = repo;
            _accountClient = accountClient;
            _mapper = mapper;
        }

        public async Task<List<LoanDto>> GetLoans(string userId)
        {
            var loans = await _repo.GetByUserIdAsync(userId);

            if (loans == null || !loans.Any())
                return new List<LoanDto>(); // return empty, not error

            return _mapper.Map<List<LoanDto>>(loans);
        }

        public async Task<LoanDto> ApplyLoan(CreateLoanDto dto, string userId)
        {
            var loan = _mapper.Map<Loan>(dto);

            loan.UserId = userId;
            loan.Status = "Pending";
            loan.CreatedAt = DateTime.Now;

            // EMI Calculation
            var r = dto.InterestRate / 12 / 100;
            var n = dto.TenureMonths;

            loan.EMI = (dto.Amount * r * (decimal)Math.Pow((double)(1 + r), n))
                       / (decimal)(Math.Pow((double)(1 + r), n) - 1);

            await _repo.AddAsync(loan);

            return _mapper.Map<LoanDto>(loan);
        }

        public async Task ApproveLoan(int loanId, string token)
        {
            var loan = await _repo.GetByIdAsync(loanId);

            loan.Status = "Approved";

            // Credit amount to account
            await _accountClient.Deposit(loan.AccountId, loan.Amount, token);

            await _repo.UpdateAsync(loan);
        }
    }
}
