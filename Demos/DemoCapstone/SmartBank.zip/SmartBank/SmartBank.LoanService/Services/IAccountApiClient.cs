﻿namespace SmartBank.LoanService.Services
{
    public interface IAccountApiClient
    {
        Task Deposit(int accountId, decimal amount, string token);
    }
}
