﻿using SmartBank.LoanService.DTOs;

namespace SmartBank.LoanService.Services
{
    public interface ILoanService
    {
        Task<LoanDto> ApplyLoan(CreateLoanDto dto, string userId);
        Task ApproveLoan(int loanId, string token);
        Task<List<LoanDto>> GetLoans(string userId);
    }
}
