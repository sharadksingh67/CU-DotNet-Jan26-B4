﻿using AutoMapper;
using SmartBank.TransactionService.DTOs;
using SmartBank.TransactionService.Models;

namespace SmartBank.TransactionService.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Transaction, TransactionDto>();

            CreateMap<CreateTransactionDto, Transaction>()
                .ForMember(dest => dest.Date,
                           opt => opt.MapFrom(src => DateTime.Now));
        }
    }
}
