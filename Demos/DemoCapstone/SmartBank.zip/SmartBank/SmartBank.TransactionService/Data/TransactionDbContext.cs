﻿using Microsoft.EntityFrameworkCore;
using SmartBank.TransactionService.Models;

namespace SmartBank.TransactionService.Data
{
    public class TransactionDbContext : DbContext
    {
        public TransactionDbContext(DbContextOptions<TransactionDbContext> options)
            : base(options)
        {
        }

        public DbSet<Transaction> Transactions { get; set; }
    }
}
