﻿using AutoMapper;
using SmartBank.TransactionService.DTOs;
using SmartBank.TransactionService.Models;
using SmartBank.TransactionService.Repositories;

namespace SmartBank.TransactionService.Services
{
    public class TransactionService : ITransactionService
    {
        private readonly ITransactionRepository _repository;
        private readonly IMapper _mapper;

        public TransactionService(ITransactionRepository repository,
                                  IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<TransactionDto> CreateTransaction(CreateTransactionDto dto)
        {
            var transaction = _mapper.Map<Transaction>(dto);

            await _repository.AddAsync(transaction);

            return _mapper.Map<TransactionDto>(transaction);
        }

        public async Task<List<TransactionDto>> GetAccountTransactions(int accountId)
        {
            var transactions = await _repository.GetByAccountIdAsync(accountId);

            return _mapper.Map<List<TransactionDto>>(transactions);
        }
    }
}
