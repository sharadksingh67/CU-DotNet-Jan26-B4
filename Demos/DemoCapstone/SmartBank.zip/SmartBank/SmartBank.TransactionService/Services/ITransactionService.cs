﻿using SmartBank.TransactionService.DTOs;

namespace SmartBank.TransactionService.Services
{
    public interface ITransactionService
    {
        Task<TransactionDto> CreateTransaction(CreateTransactionDto dto);

        Task<List<TransactionDto>> GetAccountTransactions(int accountId);
    }
}
