﻿namespace SmartBank.TransactionService.DTOs
{
    public class TransactionDto
    {
        public int Id { get; set; }

        public int AccountId { get; set; }

        public decimal Amount { get; set; }

        public string Type { get; set; } = string.Empty;

        public DateTime Date { get; set; }

        public string Description { get; set; } = string.Empty;
    }
}
