﻿namespace SmartBank.MVC.DTOs
{
    public class AccountDto
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; }
        public string Name { get; set; }
        public decimal Balance { get; set; }
    }
}
