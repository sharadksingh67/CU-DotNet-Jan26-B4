﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.ComponentModel.DataAnnotations;

namespace SmartBank.MVC.Models
{
    public class QuestionRating
    {
        [BindNever]
        public string Question { get; set; }
        
        public int Rating { get; set; } // 1–5
    }
}
