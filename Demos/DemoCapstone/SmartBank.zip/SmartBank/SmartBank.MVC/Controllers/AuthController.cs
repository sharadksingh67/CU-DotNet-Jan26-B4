﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SmartBank.MVC.ViewModels;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace SmartBank.MVC.Controllers
{
    public class AuthController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public AuthController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            var client = _factory.CreateClient("Gateway");

            var content = new StringContent(
                JsonConvert.SerializeObject(model),
                Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync("auth/login", content);

            if (!response.IsSuccessStatusCode)
                return View(model);

            // Read body and extract token property (Auth API returns { "token": "<jwt>" })
            var json = await response.Content.ReadAsStringAsync();

            string token;
            try
            {
                var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
                if (dict != null && dict.TryGetValue("token", out var t))
                    token = t;
                else
                    token = json.Trim('"'); // fallback if API returned raw string
            }
            catch
            {
                token = json.Trim('"');
            }

            HttpContext.Session.SetString("JWT", token);

            return RedirectToAction("Index", "Home");
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            // 1. Validate Model
            if (!ModelState.IsValid)
                return View(model);

            var client = _factory.CreateClient("Gateway");

            // 2. Map ViewModel → DTO (API contract expected by AuthService.RegisterDto)
            var dto = new
            {
                Email = model.Email,
                Password = model.Password,
                FullName = model.Name,
                Role = "Customer"
            };

            var content = new StringContent(
                JsonConvert.SerializeObject(dto),
                Encoding.UTF8,
                "application/json");

            // 3. Call API via Gateway
            var response = await client.PostAsync("auth/register", content);

            // 4. Handle Failure
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();

                ViewBag.Error = string.IsNullOrEmpty(error)
                    ? "Registration failed"
                    : error;

                return View(model);
            }

            // 5. Success → Redirect to Login
            return RedirectToAction("Login");

        }

        

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("JWT");

            return RedirectToAction("Index", "Home");
        }

        public IActionResult Profile()
        {
            var token = HttpContext.Session.GetString("JWT");

            string email = null;

            if (!string.IsNullOrEmpty(token))
            {
                try
                {
                    var handler = new JwtSecurityTokenHandler();
                    var jwt = handler.ReadJwtToken(token);

                    // common claim types to check
                    email = jwt.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value
                        ?? jwt.Claims.FirstOrDefault(c => c.Type == "name")?.Value
                        ?? jwt.Claims.FirstOrDefault(c => c.Type == "unique_name")?.Value
                        ?? jwt.Claims.FirstOrDefault(c => c.Type == "email")?.Value;
                }
                catch
                {
                    // ignore parse errors
                }
            }

            ViewBag.Email = email;

            return View();
        }
    }
}
