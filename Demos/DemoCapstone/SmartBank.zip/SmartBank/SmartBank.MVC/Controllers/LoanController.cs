﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SmartBank.MVC.DTOs;
using SmartBank.MVC.Models;
using SmartBank.MVC.ViewModels;
using System.Net.Http.Headers;
using System.Text;

namespace SmartBank.MVC.Controllers
{
    [SmartBank.MVC.Filters.RequireJwt]
    public class LoanController : Controller
    {
        private readonly IHttpClientFactory _factory;

        public LoanController(IHttpClientFactory factory)
        {
            _factory = factory;
        }

        // GET: /Loan
        public async Task<IActionResult> Index()
        {
            var client = _factory.CreateClient("Gateway");

            // 1. Get JWT from session
            var token = HttpContext.Session.GetString("JWT");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Auth");
            }

            // 2. Attach token
            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            // 3. Call Loan API via Gateway
            var response = await client.GetAsync("loans");

            // 4. Handle failure
            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Unable to fetch loans";
                return View(new List<LoanDto>());
            }

            // 5. Deserialize response
            var data = await response.Content.ReadAsStringAsync();

            var loans = JsonConvert.DeserializeObject<List<LoanDto>>(data);

            // detect if current user has Admin role from JWT (for showing Approve button)
            token = HttpContext.Session.GetString("JWT");
            var isAdmin = false;

            if (!string.IsNullOrEmpty(token))
            {
                try
                {
                    var handler = new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler();
                    var jwt = handler.ReadJwtToken(token);
                    isAdmin = jwt.Claims.Any(c => c.Type == System.Security.Claims.ClaimTypes.Role && c.Value == "Admin")
                              || jwt.Claims.Any(c => c.Type == "role" && c.Value == "Admin");
                }
                catch
                {
                    // ignore
                }
            }

            ViewBag.IsAdmin = isAdmin;

            // 6. Return to view
            return View(loans);
        }

        [HttpPost]
        public async Task<IActionResult> Approve(int id)
        {
            var client = _factory.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            if (string.IsNullOrEmpty(token))
                return RedirectToAction("Login", "Auth");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var response = await client.PostAsync($"loans/{id}/approve", null);

            if (!response.IsSuccessStatusCode)
            {
                TempData["Error"] = "Unable to approve loan.";
            }

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Apply()
        {
            var client = _factory.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            if (string.IsNullOrEmpty(token))
                return RedirectToAction("Login", "Auth");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            // Get accounts for the select list
            var response = await client.GetAsync("accounts");

            if (response.IsSuccessStatusCode)
            {
                var data = await response.Content.ReadAsStringAsync();
                var accounts = JsonConvert.DeserializeObject<List<AccountDto>>(data) ?? new List<AccountDto>();
                ViewBag.Accounts = accounts;
            }
            else
            {
                ViewBag.Accounts = new List<AccountDto>();
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Apply(ApplyLoanViewModel model)
        {
            var client = _factory.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            if (string.IsNullOrEmpty(token))
                return RedirectToAction("Login", "Auth");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            if (!ModelState.IsValid)
            {
                // repopulate accounts for the select list
                var resp = await client.GetAsync("accounts");
                if (resp.IsSuccessStatusCode)
                {
                    var data = await resp.Content.ReadAsStringAsync();
                    ViewBag.Accounts = JsonConvert.DeserializeObject<List<AccountDto>>(data) ?? new List<AccountDto>();
                }
                else
                {
                    ViewBag.Accounts = new List<AccountDto>();
                }

                return View(model);
            }

            // Map ViewModel → DTO including AccountId
            var dto = new
            {
                accountId = model.AccountId,
                amount = model.Amount,
                interestRate = model.InterestRate,
                tenureMonths = model.TenureMonths
            };

            var content = new StringContent(
                Newtonsoft.Json.JsonConvert.SerializeObject(dto),
                Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync("loans", content);

            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                ViewBag.Error = string.IsNullOrEmpty(error)
                    ? "Loan application failed"
                    : error;

                // repopulate accounts when returning
                var resp = await client.GetAsync("accounts");
                if (resp.IsSuccessStatusCode)
                {
                    var data = await resp.Content.ReadAsStringAsync();
                    ViewBag.Accounts = JsonConvert.DeserializeObject<List<AccountDto>>(data) ?? new List<AccountDto>();
                }
                else
                {
                    ViewBag.Accounts = new List<AccountDto>();
                }

                return View(model);
            }

            return RedirectToAction("Index");
        }
    }
}
