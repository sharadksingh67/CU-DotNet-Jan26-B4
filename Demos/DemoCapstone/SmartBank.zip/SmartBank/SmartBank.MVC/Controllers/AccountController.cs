﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SmartBank.MVC.DTOs;
using System.Net.Http.Headers;
using System.Text;

namespace SmartBank.MVC.Controllers
{
    [Filters.RequireJwt]
    public class AccountController : Controller
    {
        private readonly IHttpClientFactory _client;

        public AccountController(IHttpClientFactory client)
        {
            _client = client;
        }

        public async Task<IActionResult> Index()
        {
            var client = _client.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            // Get accounts
            var response = await client.GetAsync("accounts");
            var data = await response.Content.ReadAsStringAsync();
            var accounts = JsonConvert.DeserializeObject<List<AccountDto>>(data) ?? new List<AccountDto>();

            // For each account, fetch transactions from TransactionService via gateway
            var model = new List<SmartBank.MVC.ViewModels.AccountWithTransactionsViewModel>();

            foreach (var acc in accounts)
            {
                var vm = new SmartBank.MVC.ViewModels.AccountWithTransactionsViewModel
                {
                    Account = acc
                };

                try
                {
                    var txResponse = await client.GetAsync($"transactions/account/{acc.Id}");

                    if (txResponse.IsSuccessStatusCode)
                    {
                        var txData = await txResponse.Content.ReadAsStringAsync();
                        var txs = JsonConvert.DeserializeObject<List<SmartBank.MVC.DTOs.TransactionDto>>(txData) ?? new List<SmartBank.MVC.DTOs.TransactionDto>();
                        vm.Transactions = txs;
                    }
                }
                catch
                {
                    // ignore failures per account and leave transactions empty
                }

                model.Add(vm);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Create()
        {
            var client = _client.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            if (string.IsNullOrEmpty(token))
                return RedirectToAction("Login", "Auth");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            // POST to accounts endpoint to create a new account for the logged in user
            var content = new StringContent("{}", Encoding.UTF8, "application/json");

            await client.PostAsync("accounts", content);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Deposit(int accountId, decimal amount)
        {
            var client = _client.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var content = new StringContent(
                JsonConvert.SerializeObject(new { accountId, amount }),
                Encoding.UTF8,
                "application/json");

            await client.PostAsync("accounts/deposit", content);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Withdraw(int accountId, decimal amount)
        {
            var client = _client.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            if (string.IsNullOrEmpty(token))
                return RedirectToAction("Login", "Auth");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);

            var content = new StringContent(
                JsonConvert.SerializeObject(new { accountId, amount }),
                Encoding.UTF8,
                "application/json");

            await client.PostAsync("accounts/withdraw", content);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> ApplyLoan(CreateLoanDto dto)
        {
            var client = _client.CreateClient("Gateway");

            var token = HttpContext.Session.GetString("JWT");

            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);
                  
            var content = new StringContent(
                JsonConvert.SerializeObject(dto),
                Encoding.UTF8,
                "application/json");

            await client.PostAsync("loans", content);

            return RedirectToAction("Index");
        }
    }
}
