using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SmartBank.MVC.Models;
using SmartBank.MVC.Services;

namespace SmartBank.MVC.Pages
{
    public class FeedbackModel : PageModel
    {
        private readonly FeedbackService _service;

        public FeedbackModel(FeedbackService service)
        {
            _service = service;
        }

        [BindProperty]
        public Feedback Feedback { get; set; } = new Feedback();

        public string SuccessMessage { get; set; }

        public void OnGet()
        {
            InitializeQuestions();
        }

        private void InitializeQuestions()
        {
            if (Feedback.Ratings.Count == 0)
            {
                Feedback.Ratings = GetQuestions()
                    .Select(q => new QuestionRating { Question = q })
                    .ToList();
            }
        }

        private List<string> GetQuestions()
        {
            return new List<string>
            {
                "Service Quality",
                "App Usability",
                "Support Experience",
                "Transaction Speed",
                "Overall Satisfaction"
            };
        }

        public async Task<IActionResult> OnPostAsync()
        {
            InitializeQuestions(); // ensure list count is correct

            var questions = GetQuestions();

            // 🔥 Inject questions before saving
            for (int i = 0; i < Feedback.Ratings.Count; i++)
            {
                Feedback.Ratings[i].Question = questions[i];

                // 🔥 CRITICAL FIX: remove ModelState error
                ModelState.Remove($"Feedback.Ratings[{i}].Question");
            }

            if (!ModelState.IsValid)
                return Page();

            await _service.CreateAsync(Feedback);

            SuccessMessage = "Feedback submitted successfully!";
            ModelState.Clear();

            Feedback = new Feedback();
            InitializeQuestions();

            return Page();
        }
    }
}
