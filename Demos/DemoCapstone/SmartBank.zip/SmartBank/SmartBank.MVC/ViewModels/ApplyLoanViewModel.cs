﻿using System.ComponentModel.DataAnnotations;

namespace SmartBank.MVC.ViewModels
{
    public class ApplyLoanViewModel
    {
        public int AccountId { get; set; }

        [Required]
        [Range(1000, 10000000)]
        public decimal Amount { get; set; }

        [Required]
        [Range(1, 20)]
        public int InterestRate { get; set; }

        [Required]
        [Range(6, 360)]
        public int TenureMonths { get; set; }
    }
}
