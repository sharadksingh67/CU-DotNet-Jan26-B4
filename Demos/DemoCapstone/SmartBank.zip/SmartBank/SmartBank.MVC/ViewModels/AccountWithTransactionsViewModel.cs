using SmartBank.MVC.DTOs;

namespace SmartBank.MVC.ViewModels
{
    public class AccountWithTransactionsViewModel
    {
        public AccountDto Account { get; set; }
        public List<TransactionDto> Transactions { get; set; } = new List<TransactionDto>();
    }
}
