﻿using SmartBank.AuthService.Models;

namespace SmartBank.AuthService.Services
{
    public interface ITokenService
    {
        string CreateToken(ApplicationUser user, IList<string> roles);
    }
}
