using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using SmartBank.AuthService.Controllers;
using SmartBank.AuthService.DTOs;
using SmartBank.AuthService.Models;
using SmartBank.AuthService.Services;

namespace SmartBank.UnitTests
{
    public class AuthControllerTests
    {
        private readonly Mock<UserManager<ApplicationUser>> _userManagerMock;
        private readonly Mock<ITokenService> _tokenServiceMock;
        private readonly AuthController _controller;
        private readonly Mock<ILogger<AuthController>> _loggerMock;

        public AuthControllerTests()
        {
            var store = new Mock<IUserStore<ApplicationUser>>();

            _userManagerMock = new Mock<UserManager<ApplicationUser>>(
                store.Object, null, null, null, null, null, null, null, null
            );

            _tokenServiceMock = new Mock<ITokenService>();
            _loggerMock = new Mock<ILogger<AuthController>>();

            _controller = new AuthController(
                _loggerMock.Object,
                _userManagerMock.Object,
                _tokenServiceMock.Object
            );
        }

        [Fact]
        public async Task Login_ValidUser_ReturnsToken()
        {
            var dto = new LoginDto { Email = "test@mail.com", Password = "Test@123" };
            var user = new ApplicationUser { Email = dto.Email };
            var roles = new List<string> { "Customer" };

            _userManagerMock.Setup(x => x.FindByEmailAsync(dto.Email))
                .ReturnsAsync(user);

            _userManagerMock.Setup(x => x.CheckPasswordAsync(user, dto.Password))
                .ReturnsAsync(true);

            _userManagerMock.Setup(x => x.GetRolesAsync(user))
                .ReturnsAsync(roles);

            _tokenServiceMock.Setup(x => x.CreateToken(user, roles))
                .Returns("fake-token");

            var result = await _controller.Login(dto);

            var ok = Assert.IsType<OkObjectResult>(result);
        }
    }
}
